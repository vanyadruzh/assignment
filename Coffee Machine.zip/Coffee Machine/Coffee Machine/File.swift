//
//  File.swift
//  Coffee Machine
//
//  Created by Vanya Druzhinin on 06.02.19.
//  Copyright © 2019 Vanya Druzhinin. All rights reserved.
//

import Foundation

class CoffeeMachine {
    var coffeeAvailability:Bool
    
    var amountOfCoffee:Int
    var waterBalance:Int
    
    var electricity:Bool
    var clean:Bool
//    var thereIsACup:Bool
    
    init() {
        electricity = false
        coffeeAvailability = false
        amountOfCoffee = 0
        waterBalance = 0
//        thereIsACup = false
        
        clean = false
    }
    
    func pushOn(){
        electricity = true
        amountOfCoffee = 1
        waterBalance = 0
    }
    
    func putCoffee(){
        coffeeAvailability = true
        amountOfCoffee = 10
        print("AMOUNT OF COFFEE = ",amountOfCoffee)
    }
    
    func pourWater(){
        waterBalance = 10
        print("AMOUNT OF WATER = ",waterBalance)
    }
    
    func makeCoffee(){
        if amountOfCoffee > 0 && waterBalance > 0{
            amountOfCoffee -= 1
            waterBalance -= 1
            print("AMOUNT OF COFFEE = ",amountOfCoffee)
            print("AMOUNT OF WATER = ",waterBalance)
        }
        else if amountOfCoffee == 0{
            print("NO COFFEE")
        }
    }
    
    
}
