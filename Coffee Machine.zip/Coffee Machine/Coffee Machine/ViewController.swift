//
//  ViewController.swift
//  Coffee Machine
//
//  Created by Vanya Druzhinin on 05.02.19.
//  Copyright © 2019 Vanya Druzhinin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var saeco = CoffeeMachine()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        background.setBackgroundImage(#imageLiteral(resourceName: "coffee off"), for: .normal)
        buttonCup.setBackgroundImage(#imageLiteral(resourceName: "nothing"), for: .normal)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //background
    @IBOutlet var background: UIButton!
    
    //ADD
    @IBOutlet var buttonADD: UIButton!
    
    //ON
    @IBOutlet var buttonOn: UIButton!
    
    //cup
    @IBOutlet var buttonCup: UIButton!
    
    //cappuccino
    @IBOutlet var cappuccino: UIButton!
    
    //latte
    @IBOutlet var latte: UIButton!
    
    //americano
    @IBOutlet var americano: UIButton!
    
    //espresso
    @IBOutlet var espresso: UIButton!
    
    //water balance
    @IBOutlet var waterBalance: UIButton!
    
    //water
    @IBOutlet var water: UIButton!
    
    //machine on
    @IBAction func onButtonPressed(_ sender: Any) {
        if background.currentBackgroundImage == #imageLiteral(resourceName: "coffeeOffWith"){
            background.setBackgroundImage(#imageLiteral(resourceName: "coffee on"), for: .normal)
            print("on")
        }
        else if background.currentBackgroundImage == #imageLiteral(resourceName: "coffee off") || background.currentBackgroundImage == #imageLiteral(resourceName: "coffeeOffWith"){
            background.setBackgroundImage(#imageLiteral(resourceName: "coffee on without cof"), for: .normal)
            print("on")
            saeco.pushOn()
        }
        else{
            print("off")
            if saeco.amountOfCoffee == 0{
                background.setBackgroundImage(#imageLiteral(resourceName: "coffee off"), for: .normal)
            }
            else if saeco.amountOfCoffee > 0{
                background.setBackgroundImage(#imageLiteral(resourceName: "coffeeOffWith"), for: .normal)
            }
        }
    }
    
    //if add pressed
    @IBAction func addButtonPressed(_ sender: Any) {
        if background.currentBackgroundImage == #imageLiteral(resourceName: "coffee on without cof") || saeco.amountOfCoffee < 10{
            background.setBackgroundImage(#imageLiteral(resourceName: "coffee on"), for: .normal)
            print("COFFEE ADDED")
            saeco.putCoffee()
        }
        else if background.currentBackgroundImage == #imageLiteral(resourceName: "coffee on") || background.currentBackgroundImage == #imageLiteral(resourceName: "coffee off"){
            print("ERROR")
        }
    }
    
    //for cup
    @IBAction func buttonCupPressed(_ sender: Any) {
        if buttonCup.currentBackgroundImage == #imageLiteral(resourceName: "nothing"){
            buttonCup.setBackgroundImage(#imageLiteral(resourceName: "cup off"), for: .normal)
            print("THERE IS A CUP")
        }
        else if buttonCup.currentBackgroundImage == #imageLiteral(resourceName: "cup off"){
            buttonCup.setBackgroundImage(#imageLiteral(resourceName: "nothing"), for: .normal)
            print("NO CUP")
        }
        else if buttonCup.currentBackgroundImage == #imageLiteral(resourceName: "cup on"){
            buttonCup.setBackgroundImage(#imageLiteral(resourceName: "nothing"), for: .normal)
            print("COFFEE IS VERY TASTY")
        }
    }
    
    //cappuccino pressed
    @IBAction func cappuccinoPressed(_ sender: Any) {
        if buttonCup.currentBackgroundImage == #imageLiteral(resourceName: "cup off")
        && background.currentBackgroundImage == #imageLiteral(resourceName: "coffee on")
            && saeco.amountOfCoffee > 0
            && saeco.waterBalance > 0{
            buttonCup.setBackgroundImage(#imageLiteral(resourceName: "cup on"), for: .normal)
            print("CAPPUCCINO READY")
            saeco.makeCoffee()
            if saeco.amountOfCoffee == 0{
                background.setBackgroundImage(#imageLiteral(resourceName: "coffee on without cof"), for: .normal)
                waterBalance.setBackgroundImage(#imageLiteral(resourceName: "water0"), for: .normal)
            }
            else if saeco.waterBalance == 7 {
                waterBalance.setBackgroundImage(#imageLiteral(resourceName: "water70"), for: .normal)
            }
            else if saeco.waterBalance == 4 {
                waterBalance.setBackgroundImage(#imageLiteral(resourceName: "water30"), for: .normal)
            }
        }
        else{
            print("ERROR")
        }
    }
    
    //latte pressed
    @IBAction func lattePressed(_ sender: Any) {
        if buttonCup.currentBackgroundImage == #imageLiteral(resourceName: "cup off")
            && background.currentBackgroundImage == #imageLiteral(resourceName: "coffee on")
            && saeco.amountOfCoffee > 0
            && saeco.waterBalance > 0{
            buttonCup.setBackgroundImage(#imageLiteral(resourceName: "cup on"), for: .normal)
            print("LATTE READY")
            saeco.makeCoffee()
            if saeco.amountOfCoffee == 0{
                background.setBackgroundImage(#imageLiteral(resourceName: "coffee on without cof"), for: .normal)
                waterBalance.setBackgroundImage(#imageLiteral(resourceName: "water0"), for: .normal)
            }
            else if saeco.waterBalance == 7 {
                waterBalance.setBackgroundImage(#imageLiteral(resourceName: "water70"), for: .normal)
            }
            else if saeco.waterBalance == 4 {
                waterBalance.setBackgroundImage(#imageLiteral(resourceName: "water30"), for: .normal)
            }
        }
        else{
            print("ERROR")
        }
    }
    
    //americano pressed
    @IBAction func americanoPressed(_ sender: Any) {
        if buttonCup.currentBackgroundImage == #imageLiteral(resourceName: "cup off")
            && background.currentBackgroundImage == #imageLiteral(resourceName: "coffee on")
            && saeco.amountOfCoffee > 0
            && saeco.waterBalance > 0{
            buttonCup.setBackgroundImage(#imageLiteral(resourceName: "cup on"), for: .normal)
            print("AMERICANO READY")
            saeco.makeCoffee()
            if saeco.amountOfCoffee == 0{
                background.setBackgroundImage(#imageLiteral(resourceName: "coffee on without cof"), for: .normal)
                waterBalance.setBackgroundImage(#imageLiteral(resourceName: "water0"), for: .normal)
            }
            else if saeco.waterBalance == 7 {
                waterBalance.setBackgroundImage(#imageLiteral(resourceName: "water70"), for: .normal)
            }
            else if saeco.waterBalance == 4 {
                waterBalance.setBackgroundImage(#imageLiteral(resourceName: "water30"), for: .normal)
            }
        }
        else{
            print("ERROR")
        }
    }
    
    //espresso pressed
    @IBAction func espressoPressed(_ sender: Any) {
        if buttonCup.currentBackgroundImage == #imageLiteral(resourceName: "cup off")
            && background.currentBackgroundImage == #imageLiteral(resourceName: "coffee on")
            && saeco.amountOfCoffee > 0
            && saeco.waterBalance > 0{
            buttonCup.setBackgroundImage(#imageLiteral(resourceName: "cup on"), for: .normal)
            print("ESPRESSO READY")
            saeco.makeCoffee()
            if saeco.amountOfCoffee == 0{
                background.setBackgroundImage(#imageLiteral(resourceName: "coffee on without cof"), for: .normal)
                waterBalance.setBackgroundImage(#imageLiteral(resourceName: "water0"), for: .normal)
            }
            else if saeco.waterBalance == 7 {
                waterBalance.setBackgroundImage(#imageLiteral(resourceName: "water70"), for: .normal)
            }
            else if saeco.waterBalance == 4 {
                waterBalance.setBackgroundImage(#imageLiteral(resourceName: "water30"), for: .normal)
            }
        }
        else{
            print("ERROR")
        }
    }
    
    //waterButton
    @IBAction func waterOn(_ sender: Any) {
        if waterBalance.currentBackgroundImage == #imageLiteral(resourceName: "waterFull") && saeco.waterBalance == 10{
            print("ERROR")
        }
        else{
            waterBalance.setBackgroundImage(#imageLiteral(resourceName: "waterFull"), for: .normal)
            saeco.pourWater()
        }
        
    }
}

